// import { useEffect, useRef, useState } from 'react';
// import type { LottiePlayer } from 'lottie-web';

// // const Test: FC = () => {
// //   const ref = useRef(null);
// //   useEffect(() => {
// //       import('@lottiefiles/lottie-player');
// //   });

// //   return (
// //     <div><lottie-player
// //     id="firstLottie"
// //     ref={ref}
// //     autoplay
// //     mode="normal"
// //     src="here your json link/find on lottie website"
// // /></div>
// //   )
// // }

// // export default Test