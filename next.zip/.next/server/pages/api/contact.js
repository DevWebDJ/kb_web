"use strict";
(() => {
var exports = {};
exports.id = 91;
exports.ids = [91,651];
exports.modules = {

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 558:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _transporter__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9775);

const handler = async (req, res)=>{
    if (req.method === "POST") {
        const data = req.body;
        const nom = `${data.fullName}`;
        const message = `
  <b>Nom & Prénom :</b> ${data.fullName}\r\n
  <b>Nom de l'entreprise :</b> ${data.entreprise}\r\n
  <b>Adresse Mail :</b> ${data.email}\r\n
  <b>Numéro de téléphone :</b> ${data.phone}\r\n
  <b>Besoins :</b> ${data.secteur}\r\n
  <b>Secteur d'activité :</b> ${data.activity}\r\n
  <b>Besoin exprimé :</b> ${data.besoin}\r\n
`;
        if (!data.fullName || !data.email || !data.phone || !data.secteur) {
            return res.status(400).json({
                message: "Bad request"
            });
        }
        try {
            await _transporter__WEBPACK_IMPORTED_MODULE_0__.transporter.sendMail({
                ..._transporter__WEBPACK_IMPORTED_MODULE_0__.mailOptions,
                subject: `Demande de devis - ${nom}`,
                text: message,
                html: message.replace(/\r\n/g, "<br>")
            });
            return res.redirect(302, "/");
        } catch (error) {
            console.log(error);
            return res.status(400).json({
                message: error.message
            });
        }
    }
    return res.status(400).json({
        message: "Bad request"
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler); // res.status(200).json({ success: true })


/***/ }),

/***/ 9775:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "mailOptions": () => (/* binding */ mailOptions),
/* harmony export */   "transporter": () => (/* binding */ transporter)
/* harmony export */ });
const nodemailer = __webpack_require__(5184);
const username = process.env.CPANEL_WEBMAIL_USERNAME;
const password = process.env.CPANEL_WEBMAIL_PASSWORD;
const transporter = nodemailer.createTransport({
    host: process.env.HOST,
    port: 465,
    secure: true,
    auth: {
        user: username,
        pass: password
    }
});
const mailOptions = {
    from: username,
    to: username
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(558));
module.exports = __webpack_exports__;

})();