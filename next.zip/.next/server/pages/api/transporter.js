"use strict";
(() => {
var exports = {};
exports.id = 651;
exports.ids = [651];
exports.modules = {

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 9775:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "mailOptions": () => (/* binding */ mailOptions),
/* harmony export */   "transporter": () => (/* binding */ transporter)
/* harmony export */ });
const nodemailer = __webpack_require__(5184);
const username = process.env.CPANEL_WEBMAIL_USERNAME;
const password = process.env.CPANEL_WEBMAIL_PASSWORD;
const transporter = nodemailer.createTransport({
    host: process.env.HOST,
    port: 465,
    secure: true,
    auth: {
        user: username,
        pass: password
    }
});
const mailOptions = {
    from: username,
    to: username
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(9775));
module.exports = __webpack_exports__;

})();