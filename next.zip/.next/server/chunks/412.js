"use strict";
exports.id = 412;
exports.ids = [412];
exports.modules = {

/***/ 1593:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Footer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@heroicons/react/24/outline"
var outline_ = __webpack_require__(2135);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/Copyright.js


function Copyright() {
    const [year, setYear] = (0,external_react_.useState)(new Date().getFullYear());
    (0,external_react_.useEffect)(()=>{
        const interval = setInterval(()=>{
            setYear(new Date().getFullYear());
        }, 1000);
        return ()=>clearInterval(interval);
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
        className: "mt-8 text-center text-base text-gray-400",
        children: [
            "\xa9 ",
            year,
            " KB D\xe9veloppement, All rights reserved."
        ]
    });
}
/* harmony default export */ const components_Copyright = (Copyright);

;// CONCATENATED MODULE: ./components/Footer.js






const navigation = {
    main: [
        {
            name: "Accueil",
            href: "/"
        },
        {
            name: "Nos Logiciels",
            href: "/software"
        },
        {
            name: "Services",
            href: "/services/"
        },
        {
            name: "Qui sommes-nous ?",
            href: "/about"
        }
    ],
    social: [
        {
            name: "Facebook",
            href: "https://www.facebook.com/profile.php?id=100057631592030",
            icon: (props)=>/*#__PURE__*/ jsx_runtime_.jsx("svg", {
                    fill: "currentColor",
                    viewBox: "0 0 24 24",
                    ...props,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        fillRule: "evenodd",
                        d: "M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z",
                        clipRule: "evenodd"
                    })
                })
        },
        {
            name: "Instagram",
            href: "https://www.instagram.com/kb.developpement",
            icon: (props)=>/*#__PURE__*/ jsx_runtime_.jsx("svg", {
                    fill: "currentColor",
                    viewBox: "0 0 24 24",
                    ...props,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        fillRule: "evenodd",
                        d: "M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.067.06 1.407.06 4.123v.08c0 2.643-.012 2.987-.06 4.043-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.153 1.772 4.902 4.902 0 01-1.772 1.153c-.636.247-1.363.416-2.427.465-1.067.048-1.407.06-4.123.06h-.08c-2.643 0-2.987-.012-4.043-.06-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427-.047-1.024-.06-1.379-.06-3.808v-.63c0-2.43.013-2.784.06-3.808.049-1.064.218-1.791.465-2.427a4.902 4.902 0 011.153-1.772A4.902 4.902 0 015.45 2.525c.636-.247 1.363-.416 2.427-.465C8.901 2.013 9.256 2 11.685 2h.63zm-.081 1.802h-.468c-2.456 0-2.784.011-3.807.058-.975.045-1.504.207-1.857.344-.467.182-.8.398-1.15.748-.35.35-.566.683-.748 1.15-.137.353-.3.882-.344 1.857-.047 1.023-.058 1.351-.058 3.807v.468c0 2.456.011 2.784.058 3.807.045.975.207 1.504.344 1.857.182.466.399.8.748 1.15.35.35.683.566 1.15.748.353.137.882.3 1.857.344 1.054.048 1.37.058 4.041.058h.08c2.597 0 2.917-.01 3.96-.058.976-.045 1.505-.207 1.858-.344.466-.182.8-.398 1.15-.748.35-.35.566-.683.748-1.15.137-.353.3-.882.344-1.857.048-1.055.058-1.37.058-4.041v-.08c0-2.597-.01-2.917-.058-3.96-.045-.976-.207-1.505-.344-1.858a3.097 3.097 0 00-.748-1.15 3.098 3.098 0 00-1.15-.748c-.353-.137-.882-.3-1.857-.344-1.023-.047-1.351-.058-3.807-.058zM12 6.865a5.135 5.135 0 110 10.27 5.135 5.135 0 010-10.27zm0 1.802a3.333 3.333 0 100 6.666 3.333 3.333 0 000-6.666zm5.338-3.205a1.2 1.2 0 110 2.4 1.2 1.2 0 010-2.4z",
                        clipRule: "evenodd"
                    })
                })
        },
        {
            name: "Twitter",
            href: "https://twitter.com/DeveloppementKb",
            icon: (props)=>/*#__PURE__*/ jsx_runtime_.jsx("svg", {
                    fill: "currentColor",
                    viewBox: "0 0 24 24",
                    ...props,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84"
                    })
                })
        },
        {
            name: "Linkedin",
            href: "https://www.linkedin.com/company/kb-d%C3%A9veloppement/",
            icon: fa_.FaLinkedin
        }
    ]
};
function Footer() {
    return /*#__PURE__*/ jsx_runtime_.jsx("footer", {
        className: "bg-white border-t-2",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "mx-auto max-w-7xl overflow-hidden py-12 px-6 lg:px-8",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex-col flex justify-center items-center text-gray-500 text-sm md:text-lg lg:text-xl pb-4",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "/logo_normal.svg",
                            width: 80,
                            height: 80,
                            className: "pb-4",
                            alt: "Logo"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            children: "Logiciels, Solutions Web, R\xe9seau, Cam\xe9ra"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            className: "font-bold text-primaryBlue",
                            children: "Un seul partenaire."
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                    className: "-mx-5 -my-2 flex flex-wrap justify-center",
                    "aria-label": "Footer",
                    children: navigation.main.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "px-5 py-2",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: item.href,
                                className: "text-base text-gray-500 hover:text-primaryBlue",
                                children: item.name
                            })
                        }, item.name))
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "relative mt-5",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "absolute inset-0 flex items-center",
                            "aria-hidden": "true",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full border-t border-gray-300"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "relative flex justify-center",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "bg-white px-2 text-gray-500",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(outline_.FingerPrintIcon, {
                                    className: "h-5 w-5 text-gray-500",
                                    "aria-hidden": "true"
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "mt-4 flex justify-center space-x-6",
                    children: navigation.social.map((item)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                            target: "_blank",
                            href: item.href,
                            className: "text-gray-400 hover:text-primaryBlue",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "sr-only",
                                    children: item.name
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(item.icon, {
                                    className: "h-6 w-6",
                                    "aria-hidden": "true"
                                })
                            ]
                        }, item.name))
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(components_Copyright, {})
            ]
        })
    });
}


/***/ }),

/***/ 3412:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _next_font_google_target_css_path_components_Layout_js_import_Outfit_arguments_subsets_latin_variableName_outfit___WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9044);
/* harmony import */ var _next_font_google_target_css_path_components_Layout_js_import_Outfit_arguments_subsets_latin_variableName_outfit___WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_next_font_google_target_css_path_components_Layout_js_import_Outfit_arguments_subsets_latin_variableName_outfit___WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1593);
/* harmony import */ var _Navbar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2103);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6197);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Navbar__WEBPACK_IMPORTED_MODULE_3__, framer_motion__WEBPACK_IMPORTED_MODULE_4__]);
([_Navbar__WEBPACK_IMPORTED_MODULE_3__, framer_motion__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const Layout = (props)=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_next_font_google_target_css_path_components_Layout_js_import_Outfit_arguments_subsets_latin_variableName_outfit___WEBPACK_IMPORTED_MODULE_6___default().className),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_5___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "icon",
                        type: "image/svg+xml",
                        href: "/favicon.svg"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_4__.AnimatePresence, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Navbar__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                        initial: {
                            y: 100,
                            opacity: 0
                        },
                        animate: {
                            y: 0,
                            opacity: 1
                        },
                        exit: {
                            y: -100,
                            opacity: 0
                        },
                        transition: {
                            delay: 0.25
                        },
                        children: props.children
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Footer__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2103:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Navbar)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1185);
/* harmony import */ var _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2135);
/* harmony import */ var _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _heroicons_react_20_solid__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9476);
/* harmony import */ var _heroicons_react_20_solid__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_heroicons_react_20_solid__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _data_constant__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7715);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_headlessui_react__WEBPACK_IMPORTED_MODULE_2__]);
_headlessui_react__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* This example requires Tailwind CSS v2.0+ */ 







function classNames(...classes) {
    return classes.filter(Boolean).join(" ");
}
function Navbar() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Popover, {
        className: "relative bg-white z-50",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mx-auto px-6",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex items-center justify-between border-b-2 border-gray-100 py-6 lg:justify-start lg:space-x-10",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex justify-start items-center gap-3 lg:w-0 lg:flex-1",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                href: "/",
                                className: "flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "sr-only",
                                        children: "D\xe9veloppement"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        className: "h-10 w-auto md:h-12 lg:h-10",
                                        src: "/logo_small.svg",
                                        alt: "Logo KB",
                                        height: 50,
                                        width: 50
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-[#1257A3] font-semibold lg:text-base text-sm",
                                        children: "D\xe9veloppement"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "-my-2 -mr-2 lg:hidden",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Popover.Button, {
                                className: "inline-flex items-center justify-center rounded-md bg-white p-2 text-gray-400 hover:bg-gray-100 hover:text-gray-500 focus:outline-none ",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "sr-only",
                                        children: "Open menu"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_3__.Bars3Icon, {
                                        className: "h-6 w-6",
                                        "aria-hidden": "true"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Popover.Group, {
                            as: "nav",
                            className: "hidden space-x-10 lg:flex lg:items-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                    href: "/",
                                    className: "text-base font-medium text-gray-500 hover:text-primaryBlue",
                                    children: "Accueil"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                    href: "/software",
                                    className: "text-base font-medium text-gray-500 hover:text-primaryBlue",
                                    children: "Logiciels de gestion"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Popover, {
                                    className: "relative",
                                    children: ({ open  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Popover.Button, {
                                                    className: classNames(open ? "text-primaryBlue" : "text-gray-500", "group inline-flex items-center rounded-md bg-white text-base font-medium hover:text-primaryBlue focus:outline-none "),
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: "Services"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_20_solid__WEBPACK_IMPORTED_MODULE_4__.ChevronDownIcon, {
                                                            className: classNames(open ? "text-gray-600" : "text-gray-400", "ml-2 h-5 w-5 transition duration-150 ease-in-out group-hover:text-gray-500"),
                                                            "aria-hidden": "true"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Transition, {
                                                    as: react__WEBPACK_IMPORTED_MODULE_1__.Fragment,
                                                    enter: "transition ease-out duration-200",
                                                    enterFrom: "opacity-0 translate-y-1",
                                                    enterTo: "opacity-100 translate-y-0",
                                                    leave: "transition ease-in duration-150",
                                                    leaveFrom: "opacity-100 translate-y-0",
                                                    leaveTo: "opacity-0 translate-y-1",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Popover.Panel, {
                                                        className: "absolute left-1/2 z-10 mt-3 w-screen max-w-md -translate-x-1/2 transform px-0 lg:max-w-3xl",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "overflow-hidden rounded-lg shadow-lg ",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "relative grid gap-6 bg-white px-5 py-6 md:gap-8 p-8 lg:grid-cols-2",
                                                                    children: _data_constant__WEBPACK_IMPORTED_MODULE_6__/* .services.map */ .uZ.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                                            href: item.href,
                                                                            className: "-m-3 flex items-start rounded-lg p-3 transition duration-150 ease-in-out hover:bg-gray-50",
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex flex-shrink-0 items-center justify-center rounded-full bg-primaryBlue text-white h-12 w-12",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(item.icon, {
                                                                                        className: "h-6 w-6",
                                                                                        "aria-hidden": "true"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                    className: "ml-4",
                                                                                    children: [
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                            className: "text-base font-medium text-gray-900",
                                                                                            children: item.name
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                            className: "mt-1 text-sm text-gray-500",
                                                                                            children: item.description
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            ]
                                                                        }, item.name))
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "bg-gray-50 p-8",
                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                                        href: "/services/web",
                                                                        className: "-m-3 flow-root rounded-md p-3 transition duration-150 ease-in-out hover:bg-gray-100",
                                                                        passHref: true,
                                                                        children: [
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                className: "flex items-center",
                                                                                children: [
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                        className: "text-base font-medium text-gray-900 flex",
                                                                                        children: [
                                                                                            "D\xe9veloppement application web & site internet",
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                                                                src: "/sparkle.gif",
                                                                                                height: 50,
                                                                                                width: 25,
                                                                                                alt: "sparkles"
                                                                                            })
                                                                                        ]
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                        className: "ml-3 inline-flex items-center rounded-full bg-indigo-100 px-3 py-0.5 text-xs leading-5 font-semibold text-primaryBlue",
                                                                                        children: "New"
                                                                                    })
                                                                                ]
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                className: "mt-1 block text-sm text-gray-500",
                                                                                children: "Notre nouveau service de d\xe9veloppement de sites/applications Web/Mobile vous permettra de conqu\xe9rir le monde du digital !"
                                                                            })
                                                                        ]
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                    href: "/about",
                                    className: "text-base font-medium text-gray-500 hover:text-primaryBlue",
                                    children: "Qui sommes-nous ?"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "hidden items-center justify-end lg:flex lg:flex-1 lg:w-0",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                href: "/devis",
                                className: "ml-8 inline-flex items-center justify-center whitespace-nowrap rounded-md border border-transparent bg-primaryBlue px-4 py-2 text-base font-medium text-white shadow-sm hover:bg-PBD",
                                children: "Demander un Devis"
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Transition, {
                as: react__WEBPACK_IMPORTED_MODULE_1__.Fragment,
                enter: "duration-200 ease-out",
                enterFrom: "opacity-0 scale-95",
                enterTo: "opacity-100 scale-100",
                leave: "duration-100 ease-in",
                leaveFrom: "opacity-100 scale-100",
                leaveTo: "opacity-0 scale-95",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Popover.Panel, {
                    focus: true,
                    className: "absolute inset-x-0 top-0 origin-top-right transform p-2 transition lg:hidden",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "divide-y-2 divide-gray-50 rounded-lg bg-white shadow-lg",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "px-5 pt-5 pb-6",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex items-center justify-between",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                    className: "h-10 w-auto",
                                                    src: "/logo_normal.svg",
                                                    alt: "KB D\xe9veloppement",
                                                    height: 50,
                                                    width: 50
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "-mr-2",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Popover.Button, {
                                                    className: "inline-flex items-center justify-center rounded-md bg-white p-2 text-gray-400 hover:bg-gray-100 hover:text-primaryBlue focus:outline-none",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "sr-only",
                                                            children: "Fermer"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_3__.XMarkIcon, {
                                                            className: "h-6 w-6",
                                                            "aria-hidden": "true"
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "mt-6",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                                            className: "grid gap-y-8",
                                            children: _data_constant__WEBPACK_IMPORTED_MODULE_6__/* .services.map */ .uZ.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                    href: item.href,
                                                    className: "-m-3 flex items-center rounded-md p-3 hover:bg-gray-200",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(item.icon, {
                                                            className: "h-6 w-6 flex-shrink-0 text-primaryBlue",
                                                            "aria-hidden": "true"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "ml-3 text-base font-medium text-gray-900 ",
                                                            children: item.name
                                                        })
                                                    ]
                                                }, item.name))
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "space-y-6 py-6 px-5",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "grid grid-cols-2 gap-y-4 gap-x-8",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                href: "/software",
                                                className: "text-sm font-medium text-gray-900 hover:text-primaryBlue text-center",
                                                children: "Logiciels de gestion"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                href: "/about",
                                                className: "text-sm font-medium text-gray-900 hover:text-primaryBlue text-center",
                                                children: "Qui sommes-nous ?"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                            href: "/devis",
                                            className: "flex w-full items-center justify-center rounded-md border border-transparent bg-primaryBlue px-4 py-2 text-base font-medium text-white shadow-sm hover:bg-primaryBlue",
                                            children: "Demander un Devis"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7715:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "n4": () => (/* binding */ softwareList),
/* harmony export */   "pS": () => (/* binding */ partners),
/* harmony export */   "uZ": () => (/* binding */ services)
/* harmony export */ });
/* harmony import */ var _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2135);
/* harmony import */ var _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_0__);

const services = [
    {
        name: "D\xe9veloppement application web & site internet",
        description: "Cr\xe9ation de sites web et d'applications sur mesure pour les entreprises.",
        href: "/services/web",
        icon: _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_0__.GlobeAltIcon
    },
    {
        name: "Syst\xe8me de g\xe9olocalisation (GPS)",
        description: "Suivi en temps r\xe9el de la localisation via GPS pour une utilisation professionnelle ou personnelle.",
        href: "/services/gps",
        icon: _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_0__.MapPinIcon
    },
    {
        name: "Installation cam\xe9ra de surveillance",
        description: "Cam\xe9ras de surveillance pour prot\xe9ger les lieux priv\xe9s et professionnels.",
        href: "/services/camera",
        icon: _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_0__.VideoCameraIcon
    },
    {
        name: "Installation syst\xe8me d'alarme",
        description: "Installation de syst\xe8mes d'alarme pour une s\xe9curit\xe9 maximale.",
        href: "/services/alarme",
        icon: _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_0__.ShieldCheckIcon
    },
    {
        name: "Installation de syst\xe8me de contr\xf4le d'acc\xe8s & pointeuse",
        description: "Installation de syst\xe8mes de contr\xf4le d'acc\xe8s et de pointeuse pour la gestion des employ\xe9s et la s\xe9curit\xe9 des locaux.",
        href: "/services/accessControl",
        icon: _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_0__.FingerPrintIcon
    },
    {
        name: "Installation de r\xe9seaux informatiques (Fibre optique & cuivre)",
        description: "Installation de syst\xe8mes de contr\xf4le d'acc\xe8s et de pointeuse pour la gestion des employ\xe9s et la s\xe9curit\xe9 des locaux.",
        href: "/services/sysnet",
        icon: _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_0__.ServerStackIcon
    },
    {
        name: "Maintenance du parc informatique",
        description: "Installation de syst\xe8mes de contr\xf4le d'acc\xe8s et de pointeuse pour la gestion des employ\xe9s et la s\xe9curit\xe9 des locaux.",
        href: "/services/maintenance",
        icon: _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_0__.WrenchScrewdriverIcon
    },
    {
        name: "Installation de standard t\xe9l\xe9phonique & VOIP",
        description: "Installation de syst\xe8mes de contr\xf4le d'acc\xe8s et de pointeuse pour la gestion des employ\xe9s et la s\xe9curit\xe9 des locaux.",
        href: "/services/voip",
        icon: _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_0__.PhoneIcon
    }
];
const partners = [
    {
        name: "biscorima",
        src: "/assets/clients/biscorima.jpg"
    },
    {
        name: "bya",
        src: "/assets/clients/bya.jpg"
    },
    {
        name: "CCBO",
        src: "/assets/clients/CCBO.jpg"
    },
    {
        name: "cet",
        src: "/assets/clients/cet.jpg"
    },
    {
        name: "cherrak",
        src: "/assets/clients/cherrak.png"
    },
    {
        name: "cic",
        src: "/assets/clients/cic.jpg"
    },
    {
        name: "clinique_Tabet",
        src: "/assets/clients/clinique_Tabet.png"
    },
    {
        name: "dekinsan1",
        src: "/assets/clients/dekinsan.jpg"
    },
    {
        name: "dekinsan2",
        src: "/assets/clients/dekinsan.png"
    },
    {
        name: "eden",
        src: "/assets/clients/eden.jpg"
    },
    {
        name: "eden2",
        src: "/assets/clients/eden2.png"
    },
    {
        name: "eden3",
        src: "/assets/clients/eden3.jpg"
    },
    {
        name: "eden4",
        src: "/assets/clients/eden4.jpg"
    },
    {
        name: "evacc",
        src: "/assets/clients/evacc.jpg"
    },
    {
        name: "genepi",
        src: "/assets/clients/genepi.jpg"
    },
    {
        name: "liberte",
        src: "/assets/clients/liberte.jpg"
    },
    {
        name: "mekahli",
        src: "/assets/clients/mekahli.jpg"
    },
    {
        name: "mobis",
        src: "/assets/clients/mobis.jpg"
    },
    {
        name: "ouest",
        src: "/assets/clients/ouest.jpg"
    },
    {
        name: "ozgur",
        src: "/assets/clients/ozgur.jpg"
    },
    {
        name: "palais",
        src: "/assets/clients/palais.jpg"
    },
    {
        name: "petrogaz",
        src: "/assets/clients/petrogaz.png"
    },
    {
        name: "plaza",
        src: "/assets/clients/plaza.jpg"
    },
    {
        name: "sogema",
        src: "/assets/clients/sogema.png"
    },
    {
        name: "tabet",
        src: "/assets/clients/tabet.jpg"
    },
    {
        name: "tapino",
        src: "/assets/clients/tapino.jpg"
    },
    {
        name: "tayal",
        src: "/assets/clients/tayal.png"
    },
    {
        name: "unilab",
        src: "/assets/clients/unilab.jpg"
    }
];
const softwareList = [
    {
        name: "Gestion Paie & Ressources humaines",
        desc: "un logiciel qui permet de g\xe9rer les salaires et les fiches de paie des employ\xe9s, ainsi que d'autres aspects des ressources humaines, tels que la gestion des cong\xe9s, des absences et des performances.",
        price: "80 000",
        features: [
            "Simulation Rappel",
            "CACOBATPH",
            "Frais de Mission",
            "Documents Joints",
            "Habilitations et port d'armes",
            "Dotation",
            "Suivi Recrutement"
        ]
    },
    {
        name: "Gestion de stock et Facturation",
        desc: "un logiciel qui permet de suivre les niveaux de stock d'une entreprise et de g\xe9n\xe9rer des factures pour les ventes. Il peut \xe9galement aider \xe0 g\xe9rer les commandes, les livraisons et les retours de marchandise.",
        price: "120 000",
        features: [
            "Production",
            "Importation",
            "Distribution",
            "Suivi des emplacements",
            "Gestion des lots",
            "Gestion immobilisation",
            "Vente bois et d\xe9riv\xe9s",
            "Situation crois\xe9 (client fournisseur)",
            "Suivi \xe9ch\xe9ancier (client fournisseur",
            "Situation des chauffeurs",
            "Traitement comptable",
            "Version multi-taxe",
            "Version Avanc\xe9e (droits d'acc\xe8s par dossier)",
            "Suivi bancaire et impression ch\xe8que",
            "Demande d'achat et note de frais",
            "Pont Bascule"
        ]
    },
    {
        name: "Comptabilit\xe9",
        desc: "un logiciel qui permet de g\xe9rer les finances d'une entreprise, notamment en effectuant des t\xe2ches telles que la tenue de livres comptables, la gestion des factures et des paiements, la gestion des budgets et la g\xe9n\xe9ration de rapports financiers.",
        price: "100 000",
        features: [
            "Rapprochement bancaire",
            "Analytique"
        ]
    },
    {
        name: "Promotion Immobili\xe8re",
        desc: "un logiciel qui permet de g\xe9rer les projets immobiliers, y compris la gestion des propri\xe9t\xe9s, des ventes, des locations et des contrats.",
        price: "100 000",
        features: [
            "Licence Logiciel Promotion Immobili\xe8re"
        ]
    },
    {
        name: "Gestion \xc9cole",
        desc: "un logiciel qui permet de g\xe9rer les activit\xe9s quotidiennes d'une \xe9cole, notamment la gestion des \xe9tudiants, des enseignants, des horaires, des notes et des calendriers scolaires.",
        price: "100 000",
        features: [
            "Licence Gestion \xc9cole"
        ]
    },
    {
        name: "Gestion Clinique",
        desc: "un logiciel qui permet de g\xe9rer les op\xe9rations d'une clinique, notamment la gestion des patients, des rendez-vous, des dossiers m\xe9dicaux et des facturations.",
        price: "120 000",
        features: [
            "Imagerie m\xe9dicale",
            "Laboratoire",
            "Hospitalisation",
            "Facturation"
        ]
    },
    {
        name: "Gestion Cabinet M\xe9dical",
        desc: "un logiciel qui permet de g\xe9rer les op\xe9rations d'un cabinet m\xe9dical, notamment la gestion des patients, des rendez-vous, des dossiers m\xe9dicaux et des facturations.",
        price: "60 000",
        features: [
            "1 Poste suppl\xe9mentaire gratuit + Licence Gestion Cabinet M\xe9dical"
        ]
    }
];


/***/ })

};
;