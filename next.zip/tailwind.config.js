/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    screens: {
      md: "768px",
      // => @media (min-width: 1024px) { ... }

      lg: "1280px",
      // => @media (min-width: 1280px) { ... }
    },
    extend: {
      backgroundImage: {
        heroimg: "url('/assets/hero.jpg')",
        vid: "url('/assets/vidBG1.jpg')",
      },
      colors: {
        primaryBlue: "#0D80FD",
        PBD: "#006DFC",
        g1: "#1673D8",
        g2: "#004FA5",
        black: "#252525",
      },
    },
  },
  plugins: [
    require("@tailwindcss/typography"),
    require("@tailwindcss/aspect-ratio"),
    require("@tailwindcss/forms"),
  ],
};
